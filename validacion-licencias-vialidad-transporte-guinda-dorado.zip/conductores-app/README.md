# Validación de Licencias, Vialidad y Transporte Private, S.A. de C.V.

Portal privado de acreditaciones de conductores con identidad visual guinda y bandera tricolor de México con motivo de águila. La marca de bandera es decorativa y no implica afiliación ni autorización gubernamental.

Aplicación React + Vite (con configuración explícita del complemento React) + Supabase. Cada registro tiene UUID estable y un QR que abre `https://tu-dominio/?id=<uuid>`. La ficha pública consulta el estado actualizado en Supabase; no depende del almacenamiento local del teléfono.

## 1. Requisitos
- Node.js 20.19+ o 22.12+ recomendado para Vite actual.
- Se añadió `vite.config.js` para activar el complemento oficial de React y `.gitignore` para evitar publicar secretos y artefactos de compilación.
- Proyecto Supabase.
- Dominio/hosting HTTPS para publicar la aplicación.

## 2. Preparar Supabase
1. Crea un proyecto en Supabase.
2. Abre SQL Editor y ejecuta `supabase/schema.sql`.
3. En Authentication > Sign In / Providers, habilita temporalmente el proveedor Email y permite el registro solo durante la configuración inicial.
4. Abre la aplicación y selecciona **“Primera vez aquí · Crear cuenta de administrador”**. El primer usuario creado en Supabase Auth obtiene automáticamente el rol `admin` mediante un trigger transaccional.
5. Verifica que puedes iniciar sesión y acceder al panel. Después, desactiva los nuevos registros públicos en Supabase Authentication. Los usuarios posteriores no reciben privilegios administrativos automáticamente.

6. La aplicación construye la URL pública de la fotografía a partir de `foto_path` usando el SDK de Supabase; no necesitas editar la función SQL con la URL del proyecto.

La función pública devuelve únicamente campos de ficha. No añadas CURP ni el número completo del documento a la respuesta pública.

## 3. Configurar React
```bash
npm install
cp .env.example .env.local
```
Edita `.env.local` con la URL del proyecto y la clave **publishable/anon** de Supabase:

```env
VITE_SUPABASE_URL=https://TU-PROYECTO.supabase.co
VITE_SUPABASE_ANON_KEY=TU_CLAVE_PUBLICABLE
```

Nunca coloques `service_role` ni claves secretas en variables `VITE_*`.

## 4. Ejecutar
```bash
npm run dev
```
Abre la URL que imprime Vite. Para publicar:

```bash
npm run build
```

Publica la carpeta `dist` en Vercel, Netlify o un host estático HTTPS y configura las variables de entorno en el proveedor. El proyecto incluye `vercel.json` y `netlify.toml` para redirigir las consultas al frontend. Si la aplicación usa rutas de consulta por query string (`?id=`), el host debe servir `index.html` para la ruta raíz.

## Comprobación previa a publicación
1. `npm install`
2. Configura `.env.local` con las variables de Supabase.
3. `npm run build`
4. Prueba en incógnito una URL `/?id=<uuid>` y confirma que solo se muestran los campos públicos.
5. Inicia sesión como administrador y prueba crear, editar y suspender un registro.

La compilación no pudo ejecutarse en el entorno de revisión porque el acceso al registro de npm falló por resolución DNS (`EAI_AGAIN`). No significa que la compilación haya fallado por el código; debes ejecutar el comando en un equipo con acceso a npm antes de desplegar.

## Seguridad y límites
- Los registros se comparten entre dispositivos porque residen en Supabase.
- El QR contiene un UUID de registro y abre la URL pública; no codifica la licencia ni la fotografía.
- La tabla solo concede a `anon` columnas seleccionadas; no almacenes CURP en campos públicos.
- La foto usa bucket público: publica únicamente imágenes con autorización y aviso de privacidad adecuados. Para mayor confidencialidad, cambia a bucket privado y usa un endpoint autenticado/URL firmada, entendiendo que una URL firmada no es permanente.
- El primer usuario creado después de instalar el esquema obtiene el rol `admin`; desactiva el registro público tras el alta inicial. Para administradores adicionales, crea usuarios y asigna sus roles manualmente desde Supabase.
- Ajusta los tipos de licencia a las atribuciones reales de la empresa/jurisdicción; las descripciones incluidas son ejemplos genéricos.
- Este sistema verifica el estado de un registro privado, no la autenticidad de una licencia gubernamental.
