import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY;
if (!url || !key) console.warn('Configuración pendiente: define VITE_SUPABASE_URL y VITE_SUPABASE_ANON_KEY en .env.local antes de iniciar sesión.');

export const supabase = createClient(url || 'https://invalid.local', key || 'missing-key');
