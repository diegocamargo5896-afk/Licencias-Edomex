import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { supabase } from './supabase';

const TIPOS = {
  A: 'Motocicletas: alcance sujeto a la normativa y a la acreditación aplicable.',
  B: 'Automóviles particulares: alcance sujeto a la categoría y jurisdicción aplicables.',
  C: 'Vehículos de carga: confirmar capacidad y restricciones en el documento emisor.',
  D: 'Transporte de pasajeros u otra categoría: confirmar atribuciones con el emisor.',
  E: 'Categoría especial: describir únicamente atribuciones documentadas por el emisor.',
};
const ESTADOS = ['Vigente', 'Vencido', 'Suspendido', 'Revocado'];
const vacio = { nombre: '', numero_licencia: '', tipo_licencia: 'A', descripcion_tipo: '', vigencia: '', estatus: 'Vigente', foto: null, entidad_emisora: '' };
const fecha = (v) => v ? new Date(`${v}T12:00:00`).toLocaleDateString('es-MX', { day: '2-digit', month: 'long', year: 'numeric' }) : 'No especificada';
const idDesdeUrl = () => new URLSearchParams(window.location.search).get('id');

const EMPRESA = 'Validación de Licencias, Vialidad y Transporte Private, S.A. de C.V.';

function Brand({ compact = false }) {
  return <div className={`brand-lockup ${compact ? 'brand-compact' : ''}`}>
    <div className="flag-mark" role="img" aria-label="Bandera de México">
      <span className="flag-green"/><span className="flag-white"><i aria-hidden="true">🦅</i></span><span className="flag-red"/>
    </div>
    <div className="brand-copy"><strong>{EMPRESA}</strong><span>PADRÓN PRIVADO · VERIFICACIÓN DIGITAL</span></div>
  </div>;
}

function App() {
  const [session, setSession] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [page, setPage] = useState(idDesdeUrl() ? 'public' : 'login');
  const [publicRecord, setPublicRecord] = useState(null);
  const [records, setRecords] = useState([]);
  const [form, setForm] = useState(vacio);
  const [editingId, setEditingId] = useState(null);
  const [password, setPassword] = useState({ email: '', password: '' });
  const [registerMode, setRegisterMode] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [search, setSearch] = useState('');

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setAuthReady(true); });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession));
    return () => listener.subscription.unsubscribe();
  }, []);

  const loadRecords = useCallback(async () => {
    const { data, error: e } = await supabase.from('conductores').select('id,folio,nombre,numero_licencia,tipo_licencia,descripcion_tipo,vigencia,estatus,foto_path,entidad_emisora,publicado,created_at,updated_at').order('created_at', { ascending: false });
    if (e) throw e;
    setRecords(data || []);
  }, []);

  const loadPublic = useCallback(async (id) => {
    setBusy(true); setError('');
    const { data, error: e } = await supabase.rpc('consultar_conductor', { p_id: id }).maybeSingle();
    if (e) setError('No fue posible consultar el registro. Intenta nuevamente.');
    setPublicRecord(data || null);
    setBusy(false);
  }, []);

  useEffect(() => {
    const id = idDesdeUrl();
    if (id) { setPage('public'); loadPublic(id); }
  }, [loadPublic]);

  useEffect(() => {
    if (session && page === 'login') { setPage('admin'); }
    if (session && page === 'admin') loadRecords().catch(e => setError(e.message));
  }, [session, page, loadRecords]);

  const publicUrl = (id) => `${window.location.origin}${window.location.pathname}?id=${encodeURIComponent(id)}`;
  const setField = (name, value) => setForm(old => ({ ...old, [name]: value }));

  async function registerFirstAdmin(e) {
    e.preventDefault(); setBusy(true); setError(''); setNotice('');
    try {
      if (password.password.length < 10) throw new Error('Usa una contraseña de al menos 10 caracteres.');
      const { data, error: signUpError } = await supabase.auth.signUp({
        email: password.email.trim().toLowerCase(),
        password: password.password,
      });
      if (signUpError) throw signUpError;
      if (data.session) {
        setSession(data.session); setPage('admin');
        setNotice('Cuenta creada. Si es el primer usuario registrado, tendrá el rol de administrador.');
      } else {
        setNotice('Solicitud de registro enviada. Confirma el correo si Supabase lo solicita. El primer usuario registrado obtiene el rol de administrador.');
        setRegisterMode(false);
      }
    } catch (e) {
      setError(e.message || 'No fue posible crear la cuenta.');
    } finally { setBusy(false); }
  }

  async function login(e) {
    e.preventDefault(); setBusy(true); setError('');
    const { error: e2 } = await supabase.auth.signInWithPassword({ email: password.email, password: password.password });
    if (e2) setError('No se pudo iniciar sesión. Verifica tus credenciales y que el usuario esté autorizado.');
    else { setPage('admin'); setNotice('Sesión iniciada.'); }
    setBusy(false);
  }

  async function logout() { await supabase.auth.signOut(); setSession(null); setPage('login'); setNotice('Sesión cerrada.'); }

  async function saveRecord(e) {
    e.preventDefault(); setBusy(true); setError(''); setNotice('');
    try {
      // Validar los campos antes de subir archivos para evitar fotos huérfanas.
      if (!form.nombre.trim() || !form.numero_licencia.trim() || !form.entidad_emisora.trim()) {
        throw new Error('Completa nombre, número de acreditación y entidad emisora.');
      }
      let foto_path = editingId ? records.find(r => r.id === editingId)?.foto_path || null : null;
      if (form.foto) {
        const ext = form.foto.name.split('.').pop().toLowerCase();
        if (!['jpg','jpeg','png','webp'].includes(ext)) throw new Error('La fotografía debe ser JPG, PNG o WebP.');
        if (form.foto.size > 5 * 1024 * 1024) throw new Error('La fotografía debe pesar máximo 5 MB.');
        const filePath = `${crypto.randomUUID()}.${ext}`;
        const { error: uploadError } = await supabase.storage.from('fotos-conductores').upload(filePath, form.foto, { upsert: false, contentType: form.foto.type });
        if (uploadError) throw uploadError;
        foto_path = filePath;
      }
      const payload = {
        nombre: form.nombre.trim(), numero_licencia: form.numero_licencia.trim(), tipo_licencia: form.tipo_licencia,
        descripcion_tipo: (form.descripcion_tipo.trim() || TIPOS[form.tipo_licencia]), vigencia: form.vigencia || null,
        estatus: form.estatus, foto_path, entidad_emisora: form.entidad_emisora.trim(), publicado: true,
      };
      let result;
      if (editingId) result = await supabase.from('conductores').update(payload).eq('id', editingId).select('id').single();
      else result = await supabase.from('conductores').insert(payload).select('id').single();
      if (result.error) throw result.error;
      await loadRecords(); setForm(vacio); setEditingId(null); setNotice(editingId ? 'Registro actualizado.' : 'Registro creado. El QR ya está disponible.');
    } catch (e2) { setError(e2.message || 'Ocurrió un error al guardar.'); }
    finally { setBusy(false); }
  }

  function editRecord(r) {
    setEditingId(r.id);
    setForm({ nombre: r.nombre || '', numero_licencia: r.numero_licencia || '', tipo_licencia: r.tipo_licencia || 'A', descripcion_tipo: r.descripcion_tipo || '', vigencia: r.vigencia || '', estatus: r.estatus || 'Vigente', foto: null, entidad_emisora: r.entidad_emisora || '' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function changeStatus(r, status) {
    const { error: e } = await supabase.from('conductores').update({ estatus: status }).eq('id', r.id);
    if (e) setError(e.message); else { await loadRecords(); setNotice(`Estado actualizado a: ${status}.`); }
  }

  const filtered = useMemo(() => records.filter(r => `${r.nombre} ${r.folio} ${r.numero_licencia}`.toLowerCase().includes(search.toLowerCase())), [records, search]);

  if (!authReady) return <main className="center"><div className="spinner"/><p>Preparando el portal…</p></main>;
  if (page === 'public') return <PublicPage record={publicRecord} busy={busy} error={error} />;

  if (!session) return <main className="login-shell"><section className="login-card"><Brand/><p className="eyebrow">{registerMode ? 'CONFIGURACIÓN INICIAL' : 'ACCESO ADMINISTRATIVO'}</p><h1>{registerMode ? 'Crear cuenta inicial' : 'Portal de acreditaciones'}</h1><p className="muted">{registerMode ? 'El primer usuario registrado recibirá el rol de administrador del sistema.' : 'Acceso exclusivo para personal autorizado.'}</p>{error && <p className="alert error">{error}</p>}{notice && <p className="alert success">{notice}</p>}<form onSubmit={registerMode ? registerFirstAdmin : login} className="stack"><label>Correo electrónico<input type="email" autoComplete="username" required value={password.email} onChange={e => setPassword({ ...password, email: e.target.value })}/></label><label>Contraseña<input type="password" autoComplete={registerMode ? 'new-password' : 'current-password'} minLength={registerMode ? 10 : undefined} required value={password.password} onChange={e => setPassword({ ...password, password: e.target.value })}/>{registerMode && <span className="muted inline">Mínimo 10 caracteres.</span>}</label><button className="primary" disabled={busy}>{busy ? 'Procesando…' : registerMode ? 'Crear cuenta y configurar sistema' : 'Iniciar sesión'}</button></form><button className="auth-switch" type="button" onClick={() => { setRegisterMode(v => !v); setError(''); setNotice(''); }}>{registerMode ? 'Ya tengo una cuenta · Iniciar sesión' : 'Primera vez aquí · Crear cuenta de administrador'}</button><p className="footnote">Importante: después de crear la primera cuenta, desactiva el registro público en Supabase Authentication para evitar altas innecesarias. El rol de administrador se asigna en la base de datos, nunca desde el navegador.</p></section></main>;

  return <main className="admin-shell"><header className="topbar"><div className="topbar-branding"><Brand/><p className="eyebrow">GESTIÓN PRIVADA</p><h1>Control de conductores</h1><p className="muted">Registros, acreditaciones y códigos QR</p></div><button className="secondary" onClick={logout}>Cerrar sesión ↗</button></header>
    {error && <p className="alert error">{error}</p>}{notice && <p className="alert success">{notice}</p>}
    <div className="admin-grid"><section className="panel form-panel"><div className="section-title"><div><p className="eyebrow">{editingId ? 'EDICIÓN' : 'NUEVO REGISTRO'}</p><h2>{editingId ? 'Actualizar acreditación' : 'Registrar conductor'}</h2></div><span className="step">01</span></div>
      <form onSubmit={saveRecord} className="stack"><label>Nombre completo<input required value={form.nombre} onChange={e => setField('nombre', e.target.value)} placeholder="Nombre y apellidos"/></label><label>Número de licencia o acreditación<input required value={form.numero_licencia} onChange={e => setField('numero_licencia', e.target.value)} placeholder="Folio del documento"/></label><div className="two-col"><label>Tipo de licencia<select value={form.tipo_licencia} onChange={e => { setField('tipo_licencia', e.target.value); if (!form.descripcion_tipo) setField('descripcion_tipo', TIPOS[e.target.value]); }}>{Object.keys(TIPOS).map(t => <option key={t} value={t}>Tipo {t}</option>)}</select></label><label>Estado<select value={form.estatus} onChange={e => setField('estatus', e.target.value)}>{ESTADOS.map(s => <option key={s}>{s}</option>)}</select></label></div><label>Descripción de atribuciones<textarea rows="3" value={form.descripcion_tipo} onChange={e => setField('descripcion_tipo', e.target.value)} placeholder={TIPOS[form.tipo_licencia]}/></label><label>Vigencia hasta<input type="date" value={form.vigencia} onChange={e => setField('vigencia', e.target.value)}/></label><label>Empresa emisora<input required value={form.entidad_emisora} onChange={e => setField('entidad_emisora', e.target.value)} placeholder="Nombre de la empresa o padrón"/></label><label>Fotografía del titular <span className="muted inline">(JPG, PNG o WebP; máximo 5 MB)</span><input type="file" accept="image/jpeg,image/png,image/webp" onChange={e => setField('foto', e.target.files?.[0] || null)}/></label>{form.foto && <p className="small">Foto seleccionada: {form.foto.name}</p>}<div className="button-row"><button className="primary" disabled={busy}>{busy ? 'Guardando…' : editingId ? 'Guardar cambios' : 'Crear registro y QR'}</button>{editingId && <button type="button" className="secondary" onClick={() => { setEditingId(null); setForm(vacio); }}>Cancelar</button>}</div></form></section>
      <section className="panel records-panel"><div className="section-title"><div><p className="eyebrow">DIRECTORIO</p><h2>Registros existentes <span className="count">{records.length}</span></h2></div><span className="step">02</span></div><input className="search" value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por nombre, folio o licencia…"/>{filtered.length === 0 ? <div className="empty"><span>⌕</span><h3>Sin registros para mostrar</h3><p>Registra un conductor para generar su QR individual.</p></div> : <div className="records-list">{filtered.map(r => <article className="record" key={r.id}><div className="avatar">{r.nombre?.trim()?.[0]?.toUpperCase() || 'C'}</div><div className="record-main"><h3>{r.nombre}</h3><p>{r.folio} · Tipo {r.tipo_licencia}</p><span className={`status status-${r.estatus?.toLowerCase()}`}>{r.estatus}</span><div className="record-actions"><button className="text-button" onClick={() => editRecord(r)}>Editar</button><button className="text-button" onClick={() => window.open(publicUrl(r.id), '_blank', 'noopener,noreferrer')}>Ver ficha ↗</button><button className="text-button" onClick={() => { navigator.clipboard?.writeText(publicUrl(r.id)); setNotice('Enlace copiado si el navegador permitió el acceso al portapapeles.'); }}>Copiar enlace</button></div><details className="qr-details"><summary>Mostrar QR individual</summary><div className="qr-card"><QRCodeSVG value={publicUrl(r.id)} size={180} level="H" marginSize={3}/><p>{r.nombre}</p><p className="small">{r.folio}</p><button className="secondary" onClick={() => window.open(publicUrl(r.id), '_blank', 'noopener,noreferrer')}>Probar enlace</button></div></details><label className="status-control">Cambiar estado<select value={r.estatus} onChange={e => changeStatus(r, e.target.value)}>{ESTADOS.map(s => <option key={s}>{s}</option>)}</select></label></div></article>)}</div>}</section></div>
    <footer className="admin-footer"><Brand compact/><p>Los datos personales deben tratarse conforme al aviso de privacidad de la empresa. La ficha acredita únicamente el registro privado del emisor; no es un documento gubernamental.</p></footer>
  </main>;
}

function PublicPage({ record, busy, error }) {
  if (busy) return <main className="center"><div className="spinner"/><p>Consultando acreditación…</p></main>;
  if (error || !record) return <main className="public-shell"><header className="public-header"><Brand compact/></header><section className="public-card invalid"><div className="invalid-icon">!</div><p className="eyebrow">CONSULTA DE REGISTRO</p><h1>Registro no disponible</h1><p>{error || 'No se encontró una acreditación pública con ese identificador. Verifica el QR con el emisor.'}</p><small>Esta consulta no confirma ni sustituye una licencia oficial de tránsito.</small></section></main>;
  const vencida = record.vigencia && new Date(`${record.vigencia}T23:59:59`) < new Date();
  const estado = vencida && record.estatus === 'Vigente' ? 'Vencido' : record.estatus;
  const foto = record.foto_path ? supabase.storage.from('fotos-conductores').getPublicUrl(record.foto_path).data.publicUrl : null;
  return <main className="public-shell"><header className="public-header"><Brand compact/><span className="live-dot" title="Consulta en línea"/></header><section className="public-card"><div className="validation-ribbon"><span>CONSULTA PÚBLICA</span><strong>Ficha de acreditación privada</strong></div><div className={`public-status ${estado === 'Vigente' ? 'is-valid' : 'is-invalid'}`}><span>{estado === 'Vigente' ? '✓' : '!'}</span><div><strong>{estado === 'Vigente' ? 'REGISTRO VIGENTE' : `REGISTRO ${estado?.toUpperCase()}`}</strong><small>Estado consultado en línea</small></div></div><div className="profile"><div className="photo-wrap">{foto ? <img src={foto} alt={`Fotografía de ${record.nombre}`} /> : <div className="photo-placeholder">{record.nombre?.[0]?.toUpperCase() || 'C'}</div>}<span>FOTO DE IDENTIDAD</span></div><div className="profile-info"><p className="eyebrow">PERSONA ACREDITADA</p><h1>{record.nombre}</h1><p className="issuer">Emitido por <strong>{record.entidad_emisora}</strong></p><div className="type-pill">LICENCIA TIPO {record.tipo_licencia}</div></div></div><div className="public-fields"><div><span>FOLIO DE REGISTRO</span><strong>{record.folio}</strong></div><div><span>DOCUMENTO</span><strong>{record.licencia_mascara || 'Dato protegido'}</strong></div><div><span>VIGENCIA</span><strong>{fecha(record.vigencia)}</strong></div><div className="field-wide"><span>DESCRIPCIÓN DE LA CATEGORÍA</span><p>{record.descripcion_tipo || TIPOS[record.tipo_licencia] || 'Consultar con la entidad emisora.'}</p></div></div><div className="verification-note"><span>ⓘ</span><p>Esta página muestra información del padrón privado de la entidad emisora. La consulta del QR no acredita por sí sola la autenticidad de un documento gubernamental ni sustituye una verificación oficial.</p></div><footer className="public-footer"><span>CONSULTA DIGITAL</span><span>Actualizado: {record.actualizado_en ? new Date(record.actualizado_en).toLocaleString('es-MX') : '—'}</span></footer></section><p className="privacy-note">¿Hay algún dato incorrecto? Contacta directamente a la entidad emisora que aparece en esta ficha.</p></main>;
}

export default App;
