-- Ejecuta este archivo en Supabase > SQL Editor.
-- Este sistema es un padrón privado; no representa una integración gubernamental.
create extension if not exists pgcrypto;

create table if not exists public.admin_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin')),
  created_at timestamptz not null default now()
);

create or replace function public.es_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.admin_roles ar
    where ar.user_id = (select auth.uid()) and ar.role = 'admin'
  );
$$;
revoke all on function public.es_admin() from public;
grant execute on function public.es_admin() to authenticated;

-- Bootstrap: el primer usuario creado en Supabase Auth recibe el rol admin.
-- El bloqueo transaccional evita que dos altas simultáneas reciban el rol.
create or replace function public.asignar_primer_administrador()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  perform pg_advisory_xact_lock(847202610);
  if not exists (select 1 from public.admin_roles) then
    insert into public.admin_roles (user_id, role) values (new.id, 'admin')
    on conflict (user_id) do nothing;
  end if;
  return new;
end;
$$;

drop trigger if exists asignar_primer_administrador_al_registrar on auth.users;
create trigger asignar_primer_administrador_al_registrar
after insert on auth.users for each row
execute function public.asignar_primer_administrador();

create table if not exists public.conductores (
  id uuid primary key default gen_random_uuid(),
  folio text not null unique default ('PAD-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 12))),
  nombre text not null check (length(trim(nombre)) between 2 and 160),
  numero_licencia text not null check (length(trim(numero_licencia)) between 2 and 80),
  tipo_licencia text not null check (tipo_licencia in ('A','B','C','D','E')),
  descripcion_tipo text not null default '',
  vigencia date,
  estatus text not null default 'Vigente' check (estatus in ('Vigente','Vencido','Suspendido','Revocado')),
  foto_path text,
  entidad_emisora text not null check (length(trim(entidad_emisora)) between 2 and 180),
  publicado boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.actualizar_updated_at()
returns trigger language plpgsql set search_path = '' as $$
begin new.updated_at = now(); return new; end;
$$;
drop trigger if exists conductores_updated_at on public.conductores;
create trigger conductores_updated_at before update on public.conductores
for each row execute function public.actualizar_updated_at();

alter table public.admin_roles enable row level security;
alter table public.conductores enable row level security;

-- Solo administradores pueden administrar el padrón.
drop policy if exists "admin roles read own" on public.admin_roles;
create policy "admin roles read own" on public.admin_roles for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "admin manage conductores" on public.conductores;
create policy "admin manage conductores" on public.conductores for all to authenticated using (public.es_admin()) with check (public.es_admin());

-- No concedemos acceso directo de lectura a la tabla al rol anon. La ficha pública se entrega solo por RPC.
revoke all on public.conductores from anon;
grant select, insert, update, delete on public.conductores to authenticated;
grant select on public.admin_roles to authenticated;

-- Función pública devuelve solo campos permitidos; el id es UUID del registro, no un dato personal.
create or replace function public.consultar_conductor(p_id uuid)
returns table (
  id uuid,
  folio text,
  nombre text,
  tipo_licencia text,
  descripcion_tipo text,
  vigencia date,
  estatus text,
  entidad_emisora text,
  foto_path text,
  licencia_mascara text,
  actualizado_en timestamptz
)
language sql
stable
security definer
set search_path = ''
as $$
  select c.id, c.folio, c.nombre, c.tipo_licencia, c.descripcion_tipo,
         c.vigencia, c.estatus, c.entidad_emisora, c.foto_path,
         case when length(c.numero_licencia) <= 4 then '••••' else '•••• ' || right(c.numero_licencia, 4) end,
         c.updated_at
  from public.conductores c
  where c.id = p_id and c.publicado = true
  limit 1;
$$;
revoke all on function public.consultar_conductor(uuid) from public;
grant execute on function public.consultar_conductor(uuid) to anon, authenticated;

-- Bucket público solo para fotografías que la empresa haya autorizado publicar.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('fotos-conductores', 'fotos-conductores', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 5242880, allowed_mime_types = array['image/jpeg','image/png','image/webp'];

-- Solo administradores pueden subir, modificar o borrar archivos.
drop policy if exists "admin upload driver photos" on storage.objects;
create policy "admin upload driver photos" on storage.objects for insert to authenticated with check (bucket_id = 'fotos-conductores' and public.es_admin());
drop policy if exists "admin update driver photos" on storage.objects;
create policy "admin update driver photos" on storage.objects for update to authenticated using (bucket_id = 'fotos-conductores' and public.es_admin()) with check (bucket_id = 'fotos-conductores' and public.es_admin());
drop policy if exists "admin delete driver photos" on storage.objects;
create policy "admin delete driver photos" on storage.objects for delete to authenticated using (bucket_id = 'fotos-conductores' and public.es_admin());
